package com.ecims.portlet.recoverpassword;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class RecoverPasswordPortlet
 */
public class RecoverPasswordPortlet extends MVCPortlet {
 

}
